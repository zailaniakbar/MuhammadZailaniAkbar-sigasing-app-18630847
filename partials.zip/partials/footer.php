<footer class="main-footer">
  <div class="float-right d-none d-sm-inline">
      <b>Version</b> 0.1.0
  </div>
  <strong>Copyright &copy; 2022 <a href="#">Praktikum Web</a>.</strong> All rights reserved.
  </footer>
</div>